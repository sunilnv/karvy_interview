import React from 'react';
import './App.css';
import Header from './features/header/Header';
import Home from './features/home/Home';
import {BrowserRouter as Router, Switch, Route} from 'react-router-dom';
import Flat from './features/flat/Flat';

function app() {
  return (
    <Router>
    <div className="App">
    <Header/>
      <Switch>
      <Route path="/flat">       
          <Flat/>
        </Route>
        <Route path="/">
          <Home/>
        </Route>       
      </Switch>
    </div>
    </Router>
  );
}

export default app;
