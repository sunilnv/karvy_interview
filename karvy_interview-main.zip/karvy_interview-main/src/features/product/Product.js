import React from 'react'
import './Product.css'
import { useStateValue } from '../../context/StateProvider'

function Product(props) {
    
    const [state, dispatch]= useStateValue();
    const addToLikedList = () => {
        dispatch({type: 'ADD_LIKED_PROPERTY',
        item : {
            id: props.id,
            title: props.title,
            img: props.src,
            builder : props.builder,
            price: props.price,
            rating : props.rating,

        },});
    }; 
    return (
        <div className="product">
             <img  
                    alt="rating" 
                    src={props.src}
                />
            <div className="product__heading">
                <h3>{props.title}</h3>
                <p className="product__builder">
                    <small>{props.builder}</small>
                </p>
                <div className="product__rating">
                        <h3>₹ {props.price}&nbsp;</h3>   
                    {Array(props.rating)
                        .fill()
                        .map((_,i) => (<p>⭐</p>))}         
                </div>   
                </div>
            <div>
                <button className='product__ButtonLike' onClick={addToLikedList}>Like</button>
                <button className='product__ButtonView'>View Details</button>
                
            </div>
        </div>
    )
}

export default Product
