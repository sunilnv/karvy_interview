import React, { useEffect, useState } from 'react'
import './Home.css'
import Product from '../product/Product'


function Home() {

    const [product, setProduct] = useState({})

    useEffect(() => {
        fetch('https://www.dotcomkart.com/globelSearch?from=home&propertytype=buy&selectedCity=1', {
            method: 'GET',
            headers: {
              'Content-Type':  'text/html; charset=UTF-8',
            },
          })
            .then((response) => response.json())
            .then((data)=> {    
                setProduct(data)
            })
            .catch((error) => console.error(error))
        
    }, [])

    return (
        <div className="">
            <div className="home__title">
            <img className="home__line" src="https://dl24rpa1r5kps.cloudfront.net/public/img/line.png"/>
            <h2>Residential Projects in Mumbai</h2>
		    <h3 className="home__line">Best Livability Rating Projects</h3>        
        </div>
            <div className="home__row">
            <Product 
                id={1}
                title="Godrej Elements"
                price={'50L-1Cr'}
                builder={'By Godrej Groups'}
                src = "https://dl24rpa1r5kps.cloudfront.net/admin/public/images/property_gallery/5e8f0387731da_1.webp"
                rating={4}
            />
            <Product
              id={2}
              title="Godrej 24"
                src = "https://dl24rpa1r5kps.cloudfront.net/admin/public/images/property_gallery/5e8f05ec40d67_1.webp"
                price={'90L-1.2Cr'}
                builder = {'By Godrej Groups'}
                rating={2}
            />  
            <Product
              id={3}
              title="Lodha Riviera"
                src = "https://dl24rpa1r5kps.cloudfront.net/admin/public/images/property_gallery/5ed0df0f430aa_4.webp"
                price={'60L-80L'}
                builder ={'By Lodha Group'}
                rating={4}
            /> 

            </div>
        </div>
    )
}

export default Home
