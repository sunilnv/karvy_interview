import React from 'react'
import './Flat.css'
import Subtotal from '../subtotal/Subtotal'

function Flat() {
    return (
        <div className="flat">
            <div className="flat__left">    
                <div>
                    <h2 className="flat__title">Your Liked Flats</h2>
                </div>
            </div>
            <div className="flat__right">
                <Subtotal/>
            </div>
        </div>
    )
}

export default Flat
