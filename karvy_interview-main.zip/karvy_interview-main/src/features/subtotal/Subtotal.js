import React from 'react'
import { useStateValue } from '../../context/StateProvider';
import './Subtotal.css';

function Subtotal() {
    const [{flatLiked}, dispatch]=useStateValue();
    return (
        <div className="subtotal">
            <p>Find the list below</p>
            <div>
            { flatLiked.length?  flatLiked.map((product)=> {
                    return (
                        <ul>
                            <li>{product.title}__ Rate : {product.price}
                            </li>
                            
                        </ul>
                    )
                }) : <h3>No Flats Liked</h3>}
            </div>
        </div>
    )
}

export default Subtotal
