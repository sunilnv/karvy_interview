import React from 'react'
import './Header.css';
import SearchIcon from '@material-ui/icons/Search';
import MenuIcon from '@material-ui/icons/Menu';
import {Link} from 'react-router-dom'
import { useStateValue } from '../../context/StateProvider';

function Header() {
    const [{flatLiked}, dispatch]=useStateValue();
    return (
        <div className= "header">
          <div className="header__top">
          <Link to='/'>
            <img 
                alt="logo"
                className="header__logo"
                src= "https://dl24rpa1r5kps.cloudfront.net/public/img/home-bazaar-logo.png"
            /> 
          </Link>
          
          <div className="header__nav">
              <div className="header__option">
                <span className="header__optionLineOne">Buy</span>
                
              </div>
              <div className="header__option">
                <span className="header__optionLineOne">Sell</span>
               
              </div>
              <div className="header__option">
                <span className="header__optionLineOne">Rent</span>
               
              </div>
              <Link to='/flat'>
                <div className="header__count">
                    <MenuIcon/>
                    <span className="header__likeCount">{flatLiked.length}</span>
                </div>
            </Link>
          </div>
          </div>
          <h3 className="header__h3">No Brokerage, <br></br>No Service Charges for Buyers</h3>
          <ul class="header__list">
                        <li className="header__listItems"><a className="buyeeee"  >Buy New</a></li>
                        <li className="header__listItems"><a className="renteeee" >Rent</a></li>
                        <li className="header__listItems"><a className ="resaleee">Buy Resale</a></li>

          </ul>
          <div className="header__search">
              <input
                className="header__searchInput"
                type="text"
              />
              <SearchIcon className="header__searchIcon"/>
          </div>
        </div>
    )
}

export default Header
