export const initialState = {
    flatLiked : [],
};

const reducer = (state, action)=> {
    console.log(action)
    switch(action.type){
        case 'ADD_LIKED_PROPERTY' : 
            return {
                ...state,
                flatLiked : [...state.flatLiked, action.item]
            };

        default: return {...state}

    }
 };

 export default reducer
